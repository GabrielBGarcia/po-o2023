public class Pessoa{
private Data nascimento;
private String nome;

}
