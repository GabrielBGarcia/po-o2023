public class Pessoa{
private short dia;
private short mes;
private short ano;
public short idade
}
