public class Pessoa{
private Data nascimento;
private String nome;
private Pessoa pai;
private Pessoa mae;
}
