public class Livro extends Object{

}
