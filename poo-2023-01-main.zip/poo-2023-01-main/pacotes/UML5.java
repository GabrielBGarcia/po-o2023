public abstract class Pessoa{

}
